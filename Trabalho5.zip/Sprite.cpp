//
// Created by DELL on 17/06/2022.
//

#include "Sprite.h"
#include "Resources.h"
#include "Game.h"
#include "Camera.h"

Sprite::Sprite(GameObject &associated) : Component(associated) {
    texture = nullptr;
    scale = Vec2(1,1);
}

Sprite::Sprite(GameObject &associated,const string& file) : Component(associated) {
    texture = nullptr;
    Open(file);
    //associated.box.W = width;
    //associated.box.H = height;
    scale.X = 1;
    scale.Y = 1;
}


Sprite::~Sprite() {
    //if (texture!=nullptr) {
    //    SDL_DestroyTexture(texture);
    //}
}

void Sprite::Open(const string& file) {
    texture = Resources::GetImage(file);

    SDL_QueryTexture(texture, nullptr, nullptr, &width, &height);
    associated.box.W = width;
    associated.box.H = height;
    SetClip(0, 0, width, height);
}

void Sprite::SetClip(int x, int y, int w, int h) {
    clipRect.x = x;
    clipRect.y = y;
    clipRect.w = w;
    clipRect.h = h;
}

void Sprite::Render(int x, int y) {
    SDL_Renderer* renderer = Game::GetInstance().GetRenderer();
    SDL_Rect destinyRectangle;

    destinyRectangle.x = x;
    destinyRectangle.y = y;
    destinyRectangle.h = clipRect.h * scale.X;
    destinyRectangle.w = clipRect.w * scale.X;

    SDL_RenderCopyEx(renderer, texture, &clipRect, &destinyRectangle, associated.angleDeg, nullptr , SDL_FLIP_NONE);
}

int Sprite::GetWidth() const {
    return (int)(width*scale.X);
}

int Sprite::GetHeight() const {
    return (int)(height*scale.Y);
}

bool Sprite::IsOpen() {
    return texture != nullptr;
}

void Sprite::Render() {
    Render(static_cast<int>(associated.box.X - (int)Camera::pos.X), static_cast<int>(associated.box.Y - (int)Camera::pos.Y));
}

void Sprite::Update(float dt) {}


bool Sprite::Is(std::string type) {
    return type == "Sprite";
}

void Sprite::SetScale(float scaleX, float scaleY) {
    auto &box = associated.box;
    if(scaleX != 0){
        scale.X = scaleX;
        box.W = width * scaleX;
        box.X = box.GetCenter().X - box.W/2;
    }

    if(scaleY != 0){
        scale.Y = scaleY;
        box.H = height * scaleY;
        box.Y = box.GetCenter().Y - box.H/2;
    }
}

Vec2 Sprite::GetScale() {
    return scale;
}
